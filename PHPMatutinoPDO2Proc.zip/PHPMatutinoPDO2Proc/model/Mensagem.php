<?php

class Mensagem {
    private $msg;
    
    function getMsg() {
        return $this->msg;
    }

    function setMsg($msg) {
        $this->msg = $msg;
    }
}
