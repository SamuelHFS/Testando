<?php
session_start();
echo $_SESSION['aluno'];

$_SESSION['aluno']  = "Nathalia";